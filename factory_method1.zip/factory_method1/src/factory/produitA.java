package factory;

public  abstract  class produitA {
	public abstract void methodeA();
	public produitA() {
		// TODO Auto-generated constructor stub
	}

}
