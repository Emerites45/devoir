package factory;

public class produitA1 extends produitA {

	
	
	
	public produitA1() {
	}

	@Override
	public void methodeA() {
		System.out.println("je suis un produit de type A1");
		System.out.println("produitA1.methodeA");
	}

}

