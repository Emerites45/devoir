package factory2;

public class produitA1  extends produitA{

	
	public void methodeA() {
		System.out.println("je suis un produit de type A1");
		System.out.println("produitA1.methodeA");
	}
	public produitA1() {
		// TODO Auto-generated constructor stub
	}

}
