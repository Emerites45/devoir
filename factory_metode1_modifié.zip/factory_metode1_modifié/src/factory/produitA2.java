package factory;

public class produitA2 extends produitA{

	public produitA2() {
		// TODO Auto-generated constructor stub
	}

	public void methodeA() {
		System.out.println("je suis un produit de type A2");
		System.out.println("produitA2.methodeA");
	}


}
