package factory;

public class produitA3 extends produitA{

	
	
	
	public void methodeA() {
		System.out.println("je suis un produit de type A3");
		System.out.println("produitA3.methodeA");
		}
	public produitA3() {
		// TODO Auto-generated constructor stub
	}

}
