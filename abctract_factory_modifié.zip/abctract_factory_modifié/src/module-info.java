/**
 * 
 */
/**
 * @author franck
 *
 */
module abctract_factory_modifier {
}