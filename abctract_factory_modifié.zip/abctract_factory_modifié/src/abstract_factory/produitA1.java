package abstract_factory;

public class produitA1 extends produitA {

	public void methodeA() {
		System.out.println("ProduitA1.methodeA()");
		}
}
