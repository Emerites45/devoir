package abstract_factory;

public interface ipproduitfactory {

	
	public produitA getproduitA();
	public produitB getproduitB();
 	
}
