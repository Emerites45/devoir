package abstract_factory;

public class produitA2  extends produitA{

	public void methodeA() {
		System.out.println("ProduitA2.methodeA()");
		}
}
