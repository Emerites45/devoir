package abstract_factory;

public class produitA3  extends produitA {
	public void methodeA() {
		System.out.println("ProduitA3.methodeA()");
		}

}
