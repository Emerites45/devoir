package abstract_factory;

public class produitB {

	
	public void  methodeB () {};
}
