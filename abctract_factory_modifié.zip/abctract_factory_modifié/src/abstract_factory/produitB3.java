package abstract_factory;

public class produitB3  extends produitB {
	public void methodeB() {
		System.out.println("ProduitB3.methodeB()");
		}
}
