package abstract_factory;

public class produitA {
	
	public void methodeA() {}; 

}
