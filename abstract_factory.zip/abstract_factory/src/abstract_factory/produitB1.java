package abstract_factory;

public class produitB1 extends produitB{

	public void methodeB() {
		System.out.println("ProduitB1.methodeB()");
		}
}
