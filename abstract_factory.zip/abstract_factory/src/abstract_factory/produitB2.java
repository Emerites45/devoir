package abstract_factory;

public class produitB2  extends produitB{
	public void methodeB() {
		System.out.println("ProduitB2.methodeB()");
		}
}
