/**
 * 
 */
/**
 * @author franck
 *
 */
module abstract_factory {
}