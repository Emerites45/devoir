/**
 * 
 */
/**
 * @author franck
 *
 */
module factory2 {
}